<?php

function loobek_child_register_scripts(){
    $parent_style = 'loobek-style';

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array('font-awesome-5', 'loobek-reset'), loobek_get_theme_version() );
    wp_enqueue_style( 'dainty-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );
}
add_action( 'wp_enqueue_scripts', 'loobek_child_register_scripts', 99 );
add_action( 'admin_bar_menu', function ( $wp_admin_bar ) {
	$wp_admin_bar->remove_node( 'wp-logo' );
}, 11);
if(!function_exists('dainty_custom_shortcodes')){
    add_action( 'init', 'dainty_custom_shortcodes' );
    function dainty_custom_shortcodes(){
        add_shortcode('current_year', function(){
            return date('Y');
        });
        add_shortcode( 'site_title', function(){
            return get_bloginfo( 'name' );
        });
        add_shortcode( 'company_name', function(){
            return 'Dainty Darlings Childrenswear Ltd';
        });
        add_shortcode('theme_author', function(){
            return '<span class="credits">Designed & developed with ❤️ by <a href="https://www.digitextechnologies.com" target=_blank"">Digitex</a></span>';
        });
    }
}
function custom_wc_ajax_variation_threshold( $qty, $product ) {
	return 999999999;
}
// add_filter( 'woocommerce_ajax_variation_threshold', 'custom_wc_ajax_variation_threshold', 10, 2 );

function update_variations_number(){
    return 100;
}
add_filter('woocommerce_admin_meta_boxes_variations_per_page', 'update_variations_number');

add_action( 'woocommerce_product_query', 'newest_first_default_only' );
function newest_first_default_only( $q ) {

    if ( is_admin() || ! $q->is_main_query() ) {
        return;
    }

    // Get current ordering selected by user
    $orderby = isset( $_GET['orderby'] ) ? wc_clean( $_GET['orderby'] ) : '';

    // Apply ONLY when default sorting is used
    if ( empty( $orderby ) || $orderby === 'menu_order' ) {
        $q->set( 'orderby', 'date' );
        $q->set( 'order', 'DESC' );
    }
}
// add_filter('woocommerce_rest_api_enabled', '__return_false');
add_action('admin_init', function(){
    wp_deregister_script( 'autosave' );
});
// add_filter( 'show_admin_bar', '__return_false' );
// add_filter('auto_update_plugin', '__return_false');
add_filter( 'action_scheduler_retention_period', function(){
    return 24*3600; // 1 day
});
add_filter( 'action_scheduler_queue_runner_concurrent_batches', function(){
    return 100;
});