<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:6:{s:9:"wafStatus";s:7:"enabled";s:30:"learningModeGracePeriodEnabled";i:0;s:7:"authKey";s:64:"b;{oX7mWCmyo`D`S|**^hWgiTU[.[W~T8+SYT<0sOwhd4OBqV)z6bDP]p45qY1Oz";s:7:"version";s:5:"1.1.0";s:13:"attackDataKey";i:1676;s:11:"wafDisabled";b:0;}