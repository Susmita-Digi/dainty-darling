<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=<?php echo loobek_get_theme_options('ts_maximum_scale', 1); ?>" />
	
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-N6SPQLR9');</script>
    <!-- End Google Tag Manager -->
    
    <meta name="google-site-verification" content="t-d788UG_JXUH4-wwVqrB3dg5Ft1bG-eeEUM3u8gBNs" />

	<link rel="profile" href="//gmpg.org/xfn/11" />
	<?php 
	loobek_theme_favicon();
	wp_head(); 
	?>
</head>
<body <?php body_class(); ?>>
    
    <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N6SPQLR9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

<?php
if( function_exists('wp_body_open') ){
	wp_body_open();
}
?>
<div id="page" class="hfeed site">

	<?php if( !is_page_template('page-templates/blank-page-template.php') ): ?>
		
		<!-- Page Slider -->
		<?php if( is_page() ): ?>
			<?php if( loobek_get_page_options('ts_page_slider') && loobek_get_page_options('ts_page_slider_position') == 'before_header' ): ?>
			<div class="top-slideshow">
				<div class="top-slideshow-wrapper">
					<?php loobek_show_page_slider(); ?>
				</div>
			</div>
			<?php endif; ?>
		<?php endif; ?>
		
		<?php loobek_store_notice(); ?>
		
		<?php loobek_get_header_template(); ?>
		
	<?php endif; ?>
	
	<?php do_action('loobek_before_main_content'); ?>

	<div id="main" class="wrapper <?php echo esc_attr( loobek_get_theme_options('ts_main_content_layout_fullwidth') ? 'main-content-fullwidth': '' ) ?>">